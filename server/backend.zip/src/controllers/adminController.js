const User = require("../models/User");
const Product = require("../models/Product");
const Order = require("../models/Order");

const getDashboardStats = async (req, res) => {
    try {

        const totalUsers = await User.countDocuments();

        const totalProducts = await Product.countDocuments();

        const totalOrders = await Order.countDocuments();

        const orders = await Order.find();

        const totalRevenue = orders.reduce(
            (sum, order) => sum + order.finalAmount,
            0
        );

        const recentOrders = await Order.find()
            .populate("user", "name email")
            .sort({ createdAt: -1 })
            .limit(5);

        const monthlyRevenue = await Order.aggregate([
            {
                $group: {
                    _id: {
                        month: {
                            $month: "$createdAt",
                        },
                    },
                    revenue: {
                        $sum: "$finalAmount",
                    },
                    orders: {
                        $sum: 1,
                    },
                },
            },
            {
                $sort: {
                    "_id.month": 1,
                },
            },
        ]);
        const pendingOrders = await Order.countDocuments({
            status: "pending",
        });

        const processingOrders = await Order.countDocuments({
            status: "processing",
        });

        const shippedOrders = await Order.countDocuments({
            status: "shipped",
        });

        const deliveredOrders = await Order.countDocuments({
            status: "delivered",
        });

        return res.status(200).json({
            totalUsers,
            totalProducts,
            totalOrders,
            totalRevenue,

            pendingOrders,
            processingOrders,
            shippedOrders,
            deliveredOrders,

            recentOrders,
            monthlyRevenue,
        });


    } catch (error) {
        return res.status(500).json({
            message: error.message,
        })
    }
};

module.exports = { getDashboardStats };