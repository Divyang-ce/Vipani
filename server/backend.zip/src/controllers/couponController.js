const Coupon = require("../models/Coupon")

const createCoupon = async (req, res) => {
  try {

    const {
      code,
      discountType,
      discountValue,
      expiryDate,
    } = req.body;

    const coupon = await Coupon.create({
      code,
      discountType,
      discountValue,
      expiryDate,
    });

    return res.status(201).json({
      message: "Coupon created",
      coupon,
    });

  } catch (error) {

    return res.status(500).json({
      message: error.message,
    });

  }
};

const validateCoupon = async (req, res) => {
  try {

    const { code } = req.body;

    const coupon = await Coupon.findOne({
      code: code.toUpperCase(),
      isActive: true,
    });

    if (!coupon) {
      return res.status(404).json({
        message: "Invalid coupon",
      });
    }

    if (
      coupon.expiryDate < new Date()
    ) {
      return res.status(400).json({
        message: "Coupon expired",
      });
    }

    return res.status(200).json({
      message: "Coupon valid",
      coupon,
    });

  } catch (error) {

    return res.status(500).json({
      message: error.message,
    });

  }
};

module.exports = { createCoupon, validateCoupon};