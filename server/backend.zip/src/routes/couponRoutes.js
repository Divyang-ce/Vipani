const express = require("express");
const router = express.Router();

const protect = require("../middleware/authMiddleware");
const admin = require("../middleware/adminMiddleware");

const {
  createCoupon,
  validateCoupon,
} = require("../controllers/couponController");

// Admin creates coupon
router.post(
  "/",
  protect,
  admin,
  createCoupon
);

// User validates coupon
router.post(
  "/validate",
  protect,
  validateCoupon
);

module.exports = router;