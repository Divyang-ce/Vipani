import axios from "axios";

const API = axios.create({
    baseURL: "http://localhost:5000/api",
});

API.interceptors.request.use((req) => {

    const token = localStorage.getItem("token");

    if (token) {
        req.headers.Authorization = `Bearer ${token}`;
    }

    return req;
});

export const getDashboardStats = () => {
    return API.get("/admin/dashboard");
};

export const getAllOrders = () => {
    return API.get("/order");
};

export const updateOrderStatus = (orderId, status) => {
    return API.put(`/order/${orderId}`, {
        status,
    });
};