import { useEffect, useState } from "react";
import { getDashboardStats } from "../api/adminApi";
import { Link } from "react-router-dom";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

const PIE_COLORS = ["#f59e0b", "#6366f1", "#8b5cf6", "#10b981"];

function StatCard({ label, value, icon }) {
    return (
        <div className="bg-white rounded-2xl shadow-sm p-6 flex items-center gap-4">
            <div className="text-3xl">{icon}</div>
            <div>
                <p className="text-gray-400 text-sm">{label}</p>
                <p className="text-2xl font-bold text-gray-900">{value}</p>
            </div>
        </div>
    );
}

function AdminDashboard() {
    const [stats, setStats] = useState(null);

    useEffect(() => {
        getDashboardStats().then(r => setStats(r.data)).catch(console.log);
    }, []);

    if (!stats) return (
        <div className="flex items-center justify-center py-20">
            <p className="text-gray-400 animate-pulse">Loading dashboard...</p>
        </div>
    );

    const revenueData = stats?.monthlyRevenue?.map(item => ({
        month: `Month ${item._id.month}`,
        revenue: item.revenue,
        orders: item.orders,
    })) || [];

    const statusData = [
        { name: "Pending", value: stats.pendingOrders },
        { name: "Processing", value: stats.processingOrders },
        { name: "Shipped", value: stats.shippedOrders },
        { name: "Delivered", value: stats.deliveredOrders },
    ].filter(d => d.value > 0);

    return (
        <div className="p-6">
            <div className="flex items-center justify-between mb-8">
                <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
                <div className="flex gap-3">
                    <Link to="/admin/orders" className="border border-gray-200 text-gray-600 px-4 py-2 rounded-xl text-sm font-medium hover:bg-gray-50 transition">
                        Orders
                    </Link>
                    <Link to="/admin/products" className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-indigo-700 transition">
                        Products
                    </Link>
                </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                <StatCard label="Total Users" value={stats.totalUsers} icon="👤" />
                <StatCard label="Total Products" value={stats.totalProducts} icon="📦" />
                <StatCard label="Total Orders" value={stats.totalOrders} icon="🛒" />
                <StatCard label="Total Revenue" value={`₹${stats.totalRevenue?.toLocaleString()}`} icon="💰" />
            </div>

            {/* Order Status Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                {[
                    { label: "Pending", value: stats.pendingOrders, color: "bg-yellow-50 border-yellow-200 text-yellow-700" },
                    { label: "Processing", value: stats.processingOrders, color: "bg-blue-50 border-blue-200 text-blue-700" },
                    { label: "Shipped", value: stats.shippedOrders, color: "bg-purple-50 border-purple-200 text-purple-700" },
                    { label: "Delivered", value: stats.deliveredOrders, color: "bg-green-50 border-green-200 text-green-700" },
                ].map(({ label, value, color }) => (
                    <div key={label} className={`border rounded-2xl p-4 ${color}`}>
                        <p className="text-xs font-medium opacity-70">{label}</p>
                        <p className="text-2xl font-bold mt-1">{value}</p>
                    </div>
                ))}
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-6 mb-8">
                <div className="bg-white rounded-2xl shadow-sm p-6">
                    <h2 className="text-lg font-bold text-gray-900 mb-4">Monthly Revenue</h2>
                    {revenueData.length === 0 ? (
                        <div className="flex items-center justify-center h-48 text-gray-400">No revenue data yet</div>
                    ) : (
                        <ResponsiveContainer width="100%" height={250}>
                            <BarChart data={revenueData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                                <YAxis tick={{ fontSize: 12 }} />
                                <Tooltip formatter={(v) => `₹${v}`} />
                                <Bar dataKey="revenue" fill="#6366f1" radius={[4,4,0,0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    )}
                </div>

                <div className="bg-white rounded-2xl shadow-sm p-6">
                    <h2 className="text-lg font-bold text-gray-900 mb-4">Order Status</h2>
                    {statusData.length === 0 ? (
                        <div className="flex items-center justify-center h-48 text-gray-400">No orders yet</div>
                    ) : (
                        <ResponsiveContainer width="100%" height={250}>
                            <PieChart>
                                <Pie data={statusData} dataKey="value" nameKey="name" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                                    {statusData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                    )}
                </div>
            </div>

            {/* Recent Orders */}
            <div className="bg-white rounded-2xl shadow-sm p-6">
                <h2 className="text-lg font-bold text-gray-900 mb-4">Recent Orders</h2>
                {stats.recentOrders?.length === 0 ? (
                    <p className="text-gray-400 text-center py-8">No recent orders</p>
                ) : (
                    <div className="space-y-3">
                        {stats.recentOrders?.map((order) => (
                            <div key={order._id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                                <div>
                                    <p className="font-medium text-gray-900">{order.user?.name}</p>
                                    <p className="text-gray-400 text-xs font-mono">#{order._id.slice(-8).toUpperCase()}</p>
                                </div>
                                <div className="text-right">
                                    <p className="font-bold text-gray-900">₹{order.finalAmount}</p>
                                    <span className="text-xs capitalize text-gray-400">{order.status}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}
export default AdminDashboard;
